package pt.iade.cCollector;

import javafx.application.*;
import java.io.IOException;
import javafx.scene.*;
import javafx.stage.*;
import pt.iade.cCollector.models.User;
import pt.iade.cCollector.WindowManager;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.*;


public class Main extends Application {

	@Override	
	
	public void start(Stage primaryStage) {
		WindowManager.setPrimaryStage(primaryStage);
		WindowManager.openMainWindow();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
