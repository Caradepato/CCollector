package pt.iade.cCollector.controllers;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.cell.PropertyValueFactory;
import pt.iade.cCollector.WindowManager;
import pt.iade.cCollector.models.Collection;
import pt.iade.cCollector.models.User;


public class CreateCollectionViewController {
	User user;

	public CreateCollectionViewController(User user) {
		this.user = user;	
	}

	@FXML
    private Button addCollection;

    @FXML
    private Label welcomeText;
    
    @FXML
    private Button browseCollection;
    
    public void initialize() {
	}

}
