package pt.iade.cCollector.controllers;

import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import pt.iade.cCollector.models.Collection;
import pt.iade.cCollector.models.User;

public class UserProfileViewController {


}
