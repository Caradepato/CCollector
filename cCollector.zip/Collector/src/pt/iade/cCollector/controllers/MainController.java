package pt.iade.cCollector.controllers;
import java.io.IOException;

import javax.swing.event.ChangeEvent;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import pt.iade.cCollector.Main;
import pt.iade.cCollector.WindowManager;

public class MainController {

	

}
