package pt.iade.cCollector.controllers;

import java.awt.TextArea;

import com.sun.xml.internal.ws.org.objectweb.asm.Label;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.image.ImageView;
import pt.iade.cCollector.models.Item;
import pt.iade.cCollector.models.User;

public class BookPageViewController {

	Item item;
	User user;
	
    @FXML
    private Button backButton;

    @FXML
    private ImageView bookImage;

    @FXML
    private Label bookName;

    @FXML
    private TextArea bookDescription;

    @FXML
    private Label numberBook;

    @FXML
    private ChoiceBox<String> selectBook;

    @FXML
    private TextArea usersOwn;

    @FXML
    private TextArea copyDescription;
    
    public BookPageViewController(User user, Item item) {
    	this.user = user;
    	this.item = item;
    }
    
	@FXML
    void back(ActionEvent event) {

    }
    

    
    public void initialize() {
    	//bookName;
    }
}
