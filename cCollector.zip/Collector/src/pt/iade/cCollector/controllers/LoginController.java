package pt.iade.cCollector.controllers;

import java.io.IOException;

import javax.swing.Action;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import pt.iade.cCollector.WindowManager;
import pt.iade.cCollector.models.MysqlConnection;
import pt.iade.cCollector.models.User;
public class LoginController {

	@FXML
	private TextField userField;
	
	@FXML
	private PasswordField loginPass;

	
	String pass;
	String user;
	
	
	
	/** Compare entered pass with database pass **/	
	@FXML
	public void logInClick()  {
		pass = loginPass.getText();
		user = userField.getText();
		if(MysqlConnection.verifyPassword(user, pass)) {	
			WindowManager.openUserCollectionView(new User(user, pass));
		}
		else {
			// change welcome text to wrong password
		}
	}
	
	@FXML
	public void registerClick() {
		pass = loginPass.getText();
		user = userField.getText();
		WindowManager.openCreateCollectionView(new User(user, pass));
		}
	}

