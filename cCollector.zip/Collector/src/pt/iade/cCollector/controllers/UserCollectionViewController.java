package pt.iade.cCollector.controllers;

import java.util.ArrayList;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import pt.iade.cCollector.WindowManager;
import pt.iade.cCollector.models.Collection;
import javafx.scene.control.cell.PropertyValueFactory;
import pt.iade.cCollector.models.Item;
import pt.iade.cCollector.models.User;

public class UserCollectionViewController {
	User user;

	@FXML
	TableView<Collection> collectionv = new TableView<Collection>();
	@FXML
	Button backButton;
	@FXML
	TableColumn<String, Collection> collectionColumn = new TableColumn<>("Name");
	@FXML
	TableColumn<String, Collection> descriptionColumn = new TableColumn<>("Description");	
	
	
	
	public UserCollectionViewController(User user) {
		this.user = user;
	}
	
	
	

	public void initialize() {
		@SuppressWarnings("unchecked")
		ObservableList<Collection> collections = (ObservableList<Collection>) user.getCollections();
		collectionColumn.setCellValueFactory(new PropertyValueFactory<String, Collection>("catalogueName"));
		descriptionColumn.setCellValueFactory(new PropertyValueFactory<String, Collection>("catalogueDescription"));
		collectionv.setItems(collections);
		
		
		collectionv.setOnMouseClicked(
				(event)->{ 
			Collection selectedCollection = collectionv.getSelectionModel().getSelectedItem();
				WindowManager.openBrowseCollectionView(user, selectedCollection);
				});
	}
	
	
	public void backClick() {
		WindowManager.backToMainWindow();
	}
	
	public void goToCollection() {
		//WindowManager.openBrowseCollectionView(user, 0);
	}

}
