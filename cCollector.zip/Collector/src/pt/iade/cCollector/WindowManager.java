package pt.iade.cCollector;

import java.io.IOException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import pt.iade.cCollector.controllers.BookPageViewController;
import pt.iade.cCollector.controllers.BrowseCollectionViewController;
import pt.iade.cCollector.controllers.CreateCollectionViewController;
import pt.iade.cCollector.controllers.LoginController;
import pt.iade.cCollector.controllers.MainController;
import pt.iade.cCollector.controllers.UserCollectionViewController;
import pt.iade.cCollector.models.Collection;
import pt.iade.cCollector.models.Item;
import pt.iade.cCollector.models.User;
import javafx.scene.control.Button;


public class WindowManager {

	private static Stage primaryStage;
	
	private static Stage secondaryStage;
	
	private static Scene scene;

	public static void setPrimaryStage(Stage primaryStage) {
		WindowManager.primaryStage = primaryStage;
	}
	
	
	
	public static void backToMainWindow() {
		openMainWindow();
		secondaryStage.close();
	}
	
	public static void openMainWindow() {
		openWindow("scenes/login.fxml",
				primaryStage,new LoginController());
		primaryStage.show();
	}
	
	public static void openWindow(String link, Object objct) {
		try {
			FXMLLoader loader = new FXMLLoader(Main.class.getResource(link));
			loader.setController(objct);
			Pane root;
			root = loader.load();
			scene = new Scene(root);
			secondaryStage = new Stage();
			secondaryStage.setScene(scene);
			secondaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void openCreateCollectionView(User user) {
		try {
			FXMLLoader loader = new FXMLLoader(Main.class.getResource("scenes/createCollectionView.fxml"));
			loader.setController(new CreateCollectionViewController(user));
			Pane root;
			root = loader.load();
			scene = new Scene(root);
			secondaryStage.close();
			primaryStage = new Stage();
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	public static void openUserCollectionView(User user) {
		try {
			FXMLLoader loader = new FXMLLoader(Main.class.getResource("scenes/userCollectionView.fxml"));
			loader.setController(new UserCollectionViewController(user));
			Pane root;
			root = loader.load();
			scene = new Scene(root);
			primaryStage.close();
			secondaryStage = new Stage();
			secondaryStage.setScene(scene);
			secondaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void openBrowseCollectionView(User user, Collection collection) {
		try {
			FXMLLoader loader = new FXMLLoader(Main.class.getResource("scenes/browseCollectionView.fxml"));
			loader.setController(new BrowseCollectionViewController(user, collection));
			Pane root;
			root = loader.load();
			scene = new Scene(root);
			secondaryStage.close();
			primaryStage = new Stage();
			primaryStage.setScene(scene);
			primaryStage.show();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void openBookPageView(User user, Item item) {
		try {
			FXMLLoader loader = new FXMLLoader(Main.class.getResource("scenes/bookPageView.fxml"));
			loader.setController(new BookPageViewController(user, item));
			Pane root;
			root = loader.load();
			scene = new Scene(root);
			primaryStage.close();
			secondaryStage = new Stage();
			secondaryStage.setScene(scene);
			secondaryStage.show();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	public static void openSceneInWindow(String viewPath, Stage window,
			Object controller) {
		try {
			Parent root = createNewNodeTree(viewPath, controller);
			window.getScene().setRoot(root);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static void openModalWindow(String viewPath, Stage window,
			Stage parentWindow, Object controller) {
		window.initOwner(parentWindow);
		window.initModality(Modality.APPLICATION_MODAL); 
		openWindow(viewPath, window,controller);
		
	}
	

	public static void openWindow(String viewPath, Stage window, 
			Object controller) {
		try {
			Parent root = createNewNodeTree(viewPath, controller);
			Scene scene = new Scene(root);
			//scene.getStylesheets().add(Main.class.getResource("application.css").toExternalForm());
			window.setScene(scene);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	public static Parent createNewNodeTree(String viewPath, Object controller) throws IOException {
		FXMLLoader loader = new FXMLLoader(
				Main.class.getResource(viewPath));
		loader.setController(controller);;
		Parent root = loader.load();
		return root;
	}


	
}
