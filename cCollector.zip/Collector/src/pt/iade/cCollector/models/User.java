package pt.iade.cCollector.models;

import java.util.ArrayList;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class User {
	private String email;
	private int reputation;
	private String password;
	private ObservableList<Message> messages;
	private ObservableList<Collection> collections;
	
	public User(String email, String password) {
		this.email = email;
		this.password = password;
		this.reputation = 0;
		this.messages = FXCollections.observableArrayList();;
		this.collections = MysqlConnection.getCollections(email);
	}
	
	public ObservableList<Collection> getCollections(){
		return collections;
	}
}


