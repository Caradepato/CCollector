
package pt.iade.cCollector.models;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class MysqlConnection {
	private static final String URL = "jdbc:mysql://remotemysql.com:3306/Gtwkt5USSe?useSSL=false";
	private static final String PASS = "Gtwkt5USSe";
	private static final String USER = "OxAMLiPad8";
	
	private static Connection connection = null;
	
	private MysqlConnection () {
	}
	
	/** getConnection gets the connection **/
	
	public static Connection getConnection() {
		try {
			if (connection == null || connection.isClosed()) 
				return DriverManager.getConnection(URL,USER,PASS);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
	/** getCollection returns an arrayList containing all the collections the user with the email sent via the variable "user" has in the database. **/
	
	public static ObservableList<Collection> getCollections(String user){
	  /*connection = getConnection();
	  String query = "SELECT Catalogue.name, Catalogue.description, Collection.idCollection FROM users JOIN Collection ON User.userId = Collection.user JOIN Catalogue ON Collection.catalogue = Catalogue.idCatalogue WHERE user.email LIKE '" + user +"';";
	  ArrayList<Collection> collections = new ArrayList<Collection>();
	  try {
		  Statement st = connection.createStatement();
		  ResultSet rs = st.executeQuery(query);
		  
		  while (rs.next()) {
			  String name = rs.getString("name");
			  String description = rs.getString("description");
			  int collectionId = rs.getInt("collectionId");
			  collections.add(new Collection(collectionId, name, description));
		  }
	} catch (SQLException e) {
		e.printStackTrace();
	}*/
		
	// this is dummycode.
		ObservableList<Collection> collections = FXCollections.observableArrayList();
		collections.add(new Collection(0, "The adventures of Tintin", "The reporter Tintin goes on various adventures"));
	// end of dummycode.
	  return collections;
	}
	
	/** VerifyPassword controls whether the entered password matches what is registered in the database.
	 * 	It takes the entered email and password and returns a boolean : True if it matches and False if it either does not match or if the email is not registered  **/
	
	public static boolean verifyPassword(String email, String password) {
		// this is a dummy value
		return true;
		//the above was a dummy value
		/*connection = getConnection();
		String query = "SELECT User.password FROM User WHERE userEmail LIKE '" + email + "´;";
		String pass = "";
		try {
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);
			pass = rs.getString("password");
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		if(pass.equals(password))
			return true;
		else
			return false;*/
		
	}
	
	/** getItemsFromCollectionId fetches all the items in a collection
	 * It receives the ID of the collection and returns an arrayList of all items**/
	public static ObservableList<Item> getItemsFromCollectionId(int id) {
		
		ObservableList<Item> items = FXCollections.observableArrayList();
		connection = getConnection();
		String query = "SELECT Item.name, Item.description, Item.category, Item.idItem FROM Collection JOIN Item ON Collection.catalogue = Item.catalogueId WHERE collection.idCollection LIKE '" + id + "';";
		try {
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);
				while(rs.next()) {
					String name = rs.getString("name");
					String itemDescription = rs.getString("description");
					String category = rs.getString("category");
					int itemId = rs.getInt("idItem");
					items.add(new Item(name, itemDescription, category, itemId, id ));
				}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return items;
	}
	
	/** getUserBooksInItem returns all userBooks of an item
	 * It receives the integers itemId and collectionId and returns the ArrayList of UserBooks userBooks **/
	
	public static ObservableList<userBook> getUserBooksInItem(int itemId, int collectionId) {
		//connection = getConnection();
		ObservableList<userBook> userBooks = FXCollections.observableArrayList();
		/*String query = "SELECT UserBook.description, Edition.publisher, Edition.langCode, Edition.publicationDate FROM UserBook JOIN Edition ON UserBook.idEdition = Edition.idEdition WHERE idCollection LIKE '" + collectionId + "' AND idItem LIKE '" + itemId + "';";
		
		try {
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);
			while(rs.next()) {
				String description = rs.getString("description");
				String publisher = rs.getString("publisher");
				String langCode = rs.getString("langCode");
				int publicationDate = rs.getInt("publicationDate");
				userBooks.add(new userBook(description, publisher, langCode, publicationDate));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}*/
		// this is dummy code
		if (itemId == 1) {
			return userBooks;
		}
		userBooks.add(new userBook("good condition","Sundancer","EN", 1908));
		// this is dummy code
		return userBooks;
	}
	
}
