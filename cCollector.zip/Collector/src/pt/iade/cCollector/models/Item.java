package pt.iade.cCollector.models;

import java.util.ArrayList;
import java.util.Date;

import javafx.collections.ObservableList;

public class Item {
	String name;
	String description;
	String category;
	ObservableList<userBook> userBooks;
	String bookSize;
	
	public Item(String name, String description, String category, int id, int collectionId ) {
		this.name = name;
		this.description = description;
		this.category = category;
		this.userBooks = MysqlConnection.getUserBooksInItem(id, collectionId);
		this.bookSize = "" + userBooks.size();
	}
	
	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public String getCategory() {
		return category;
	}
	
	public int getQuantity() {
		return userBooks.size();
	}
	
}
