package pt.iade.cCollector.models;

public class Edition {

}
