package pt.iade.cCollector.models;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Collection {

	private ObservableList<Item> items;
	private String catalogueName;
	private String catalogueDescription;
	
	public Collection(int collectionId, String catalogueName, String catalogueDescription) {
		this.catalogueName = catalogueName;
		this.catalogueDescription = catalogueDescription;
		//items = MysqlConnection.getItemsFromCollectionId(collectionId);
		items = FXCollections.observableArrayList();
		items.add(new Item("Tintin in the Land of the Soviets","Tintin is sent to the Soviet Union","Adventure", 0, 0));
		items.add(new Item("Tintin in the Congo", "Tintin is sent to the Congo", "Adventure", 1, 0));
		items.add(new Item("Tintin in America", "Tintin is after mobsters in America", "Adventure", 2, 0));
	}
	
	public ObservableList<Item> getItems(){
		return items;
	}
	
	public String getCatalogueName() {
		return catalogueName;
	}
	
	public String getCatalogueDescription() {
		return catalogueDescription;
	}
	
}
